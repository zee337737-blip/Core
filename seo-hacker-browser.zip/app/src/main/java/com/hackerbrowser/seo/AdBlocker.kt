package com.hackerbrowser.seo

import android.content.Context
import android.util.Log
import java.util.concurrent.atomic.AtomicInteger

object AdBlocker {
    private val domains = HashSet<String>()
    @Volatile private var loaded = false
    val blockedCount = AtomicInteger(0)

    fun load(context: Context) {
        if (loaded) return
        try {
            context.assets.open("blocklist.txt").bufferedReader().useLines { lines ->
                lines.forEach { raw ->
                    val d = raw.trim().lowercase()
                    if (d.isNotEmpty() && !d.startsWith("#")) domains.add(d)
                }
            }
            loaded = true
        } catch (e: Exception) {
            Log.w("AdBlocker", "Failed loading blocklist: ${e.message}")
        }
    }

    fun isBlocked(host: String?): Boolean {
        if (host == null) return false
        val h = host.lowercase()
        if (domains.contains(h)) return true
        var i = h.indexOf('.')
        while (i >= 0 && i < h.length - 1) {
            val parent = h.substring(i + 1)
            if (domains.contains(parent)) return true
            i = h.indexOf('.', i + 1)
        }
        return false
    }

    fun resetCount() { blockedCount.set(0) }

    const val HIDE_ADS_CSS = """
(function(){
  if (document.getElementById('__seohb_css')) return;
  var css = 'ins.adsbygoogle,[id^="google_ads"],[class*="adsbygoogle"],'
    + '[id*="banner"][class*="ad"],[class*=" ad-"],[class^="ad-"],[id^="ad-"],[id*="-ad-"],'
    + 'iframe[src*="doubleclick"],iframe[src*="googlesyndication"],'
    + '[class*="sponsored"],[id*="taboola"],[class*="outbrain"],'
    + '[class*="advertisement"],[aria-label*="Advertisement"]'
    + '{display:none !important;visibility:hidden !important;height:0 !important;}';
  var s = document.createElement('style');
  s.id = '__seohb_css';
  s.appendChild(document.createTextNode(css));
  (document.head || document.documentElement).appendChild(s);
})();
"""
}
