package com.hackerbrowser.seo

import android.content.Context

object Prefs {
    private const val NAME = "seo_hacker_prefs"
    private fun sp(c: Context) = c.getSharedPreferences(NAME, Context.MODE_PRIVATE)

    fun getSearchEngine(c: Context): String = sp(c).getString("search_engine", "google") ?: "google"
    fun setSearchEngine(c: Context, v: String) { sp(c).edit().putString("search_engine", v).apply() }

    fun getDesktopMode(c: Context): Boolean = sp(c).getBoolean("desktop", false)
    fun setDesktopMode(c: Context, v: Boolean) { sp(c).edit().putBoolean("desktop", v).apply() }

    fun getAdBlock(c: Context): Boolean = sp(c).getBoolean("adblock", true)
    fun setAdBlock(c: Context, v: Boolean) { sp(c).edit().putBoolean("adblock", v).apply() }

    fun getCohereKey(c: Context): String = sp(c).getString("cohere_key", "") ?: ""
    fun setCohereKey(c: Context, v: String) { sp(c).edit().putString("cohere_key", v).apply() }

    fun getCohereModel(c: Context): String =
        sp(c).getString("cohere_model", "command-r-plus-08-2024") ?: "command-r-plus-08-2024"
    fun setCohereModel(c: Context, v: String) { sp(c).edit().putString("cohere_model", v).apply() }

    fun getReports(c: Context): String = sp(c).getString("reports", "[]") ?: "[]"
    fun setReports(c: Context, v: String) { sp(c).edit().putString("reports", v).apply() }

    fun getBookmarks(c: Context): String = sp(c).getString("bookmarks", "[]") ?: "[]"
    fun setBookmarks(c: Context, v: String) { sp(c).edit().putString("bookmarks", v).apply() }

    fun getHistory(c: Context): String = sp(c).getString("history", "[]") ?: "[]"
    fun setHistory(c: Context, v: String) { sp(c).edit().putString("history", v).apply() }
}
