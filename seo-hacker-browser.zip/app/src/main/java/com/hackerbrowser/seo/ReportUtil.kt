package com.hackerbrowser.seo

import android.app.Activity
import android.content.ContentValues
import android.content.Context
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.view.LayoutInflater
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

object ReportUtil {

    fun saveToDownloads(ctx: Context, filename: String, content: String): Boolean {
        return try {
            if (Build.VERSION.SDK_INT >= 29) {
                val values = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, filename)
                    put(MediaStore.Downloads.MIME_TYPE, mimeFor(filename))
                    put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                }
                val resolver = ctx.contentResolver
                val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                    ?: return false
                resolver.openOutputStream(uri)?.use { it.write(content.toByteArray(Charsets.UTF_8)) }
            } else {
                val dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                if (!dir.exists()) dir.mkdirs()
                File(dir, filename).writeText(content)
            }
            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    private fun mimeFor(name: String): String = when {
        name.endsWith(".csv") -> "text/csv"
        name.endsWith(".html") -> "text/html"
        name.endsWith(".json") -> "application/json"
        else -> "text/plain"
    }

    fun addReportToHub(ctx: Context, title: String, content: String) {
        try {
            val arr = JSONArray(Prefs.getReports(ctx))
            val o = JSONObject()
                .put("title", title)
                .put("content", content)
                .put("time", System.currentTimeMillis())
            arr.put(o)
            Prefs.setReports(ctx, arr.toString())
        } catch (_: Exception) {}
    }

    fun showReport(activity: Activity, title: String, content: String) {
        val view = LayoutInflater.from(activity).inflate(R.layout.dialog_report, null)
        val tv = view.findViewById<TextView>(R.id.reportText)
        tv.text = content
        val dlg = AlertDialog.Builder(activity)
            .setTitle(title)
            .setView(view)
            .create()

        view.findViewById<Button>(R.id.btnCsv).setOnClickListener {
            val safe = title.replace(Regex("[^A-Za-z0-9._-]"), "_")
            val ok = saveToDownloads(activity, "$safe.csv", content)
            Toast.makeText(activity,
                if (ok) "Saved to Downloads/$safe.csv" else "Save failed",
                Toast.LENGTH_SHORT).show()
        }
        view.findViewById<Button>(R.id.btnTxt).setOnClickListener {
            val safe = title.replace(Regex("[^A-Za-z0-9._-]"), "_")
            val ok = saveToDownloads(activity, "$safe.txt", content)
            Toast.makeText(activity,
                if (ok) "Saved to Downloads/$safe.txt" else "Save failed",
                Toast.LENGTH_SHORT).show()
        }
        view.findViewById<Button>(R.id.btnSend).setOnClickListener {
            askSendToHub(activity, title, content)
        }
        view.findViewById<Button>(R.id.btnClose).setOnClickListener { dlg.dismiss() }
        dlg.show()
    }

    private fun askSendToHub(activity: Activity, title: String, content: String) {
        AlertDialog.Builder(activity)
            .setTitle("Send to Planning Hub?")
            .setMessage("Add this report to the Planning Hub queue?")
            .setPositiveButton("Yes") { _, _ ->
                addReportToHub(activity, title, content)
                Toast.makeText(activity, "Sent to Planning Hub", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("No", null)
            .show()
    }
}
