package com.hackerbrowser.seo

import android.webkit.WebView
import org.json.JSONArray
import org.json.JSONObject

object SeoAnalyzer {

    private val MAIN_JS = """
(function(){
  try {
    function meta(name, attr) {
      var m = document.querySelector('meta['+attr+'="'+name+'"]');
      return m ? (m.content || '') : '';
    }
    var title = document.title || '';
    var desc = meta('description','name');
    var canonical = (document.querySelector('link[rel="canonical"]') || {}).href || '';
    var robots = meta('robots','name');
    var hreflangs = [];
    document.querySelectorAll('link[rel="alternate"][hreflang]').forEach(function(l){
      hreflangs.push(l.hreflang + ' -> ' + l.href);
    });
    var og = [];
    document.querySelectorAll('meta[property^="og:"]').forEach(function(m){
      og.push(m.getAttribute('property') + ' = ' + (m.content||''));
    });
    var tw = [];
    document.querySelectorAll('meta[name^="twitter:"]').forEach(function(m){
      tw.push(m.getAttribute('name') + ' = ' + (m.content||''));
    });
    var jsonld = [];
    document.querySelectorAll('script[type="application/ld+json"]').forEach(function(s){
      jsonld.push((s.textContent||'').substring(0,2000));
    });
    var heads = {};
    for (var i=1;i<=6;i++){ heads['h'+i] = document.querySelectorAll('h'+i).length; }
    var imgsTotal = 0, imgsNoAlt = 0;
    document.querySelectorAll('img').forEach(function(i){
      imgsTotal++;
      if (!i.alt || !i.alt.trim()) imgsNoAlt++;
    });
    var text = (document.body ? document.body.innerText : '') || '';
    var words = text.trim().split(/\s+/).filter(function(w){return w.length>1});
    var wordCount = words.length;
    var freq = {};
    words.forEach(function(w){
      w = w.toLowerCase().replace(/[^a-z0-9-]/g,'');
      if (w.length > 2) freq[w] = (freq[w]||0)+1;
    });
    var top = Object.keys(freq).sort(function(a,b){return freq[b]-freq[a]})
              .slice(0,25).map(function(k){ return k + ':' + freq[k]; });
    var internal=0, external=0, nofollow=0;
    var origin = location.origin;
    var links = [];
    document.querySelectorAll('a[href]').forEach(function(a){
      var h = a.href || '';
      if (!h) return;
      if (a.rel && a.rel.toLowerCase().indexOf('nofollow')>=0) nofollow++;
      if (h.indexOf(origin)===0) internal++;
      else if (h.indexOf('http')===0) external++;
      if (links.length < 200) links.push(h);
    });
    var res = {
      url: location.href,
      title: title,
      titleLen: title.length,
      desc: desc,
      descLen: desc.length,
      canonical: canonical,
      robots: robots,
      hreflangs: hreflangs,
      og: og,
      tw: tw,
      jsonld: jsonld,
      heads: heads,
      imgsTotal: imgsTotal,
      imgsNoAlt: imgsNoAlt,
      wordCount: wordCount,
      topWords: top,
      internalLinks: internal,
      externalLinks: external,
      nofollowLinks: nofollow,
      links: links
    };
    return JSON.stringify(res);
  } catch (e) {
    return JSON.stringify({error: String(e)});
  }
})();
"""

    fun runMainAnalysis(web: WebView, cb: (JSONObject?) -> Unit) {
        web.evaluateJavascript(MAIN_JS) { value ->
            val unquoted = unquote(value)
            val obj = try { JSONObject(unquoted) } catch (_: Exception) { null }
            cb(obj)
        }
    }

    fun formatReport(o: JSONObject): String {
        val sb = StringBuilder()
        sb.append("=== SEO REPORT ===\n")
        sb.append("URL: ${o.optString("url")}\n\n")
        sb.append("-- TITLE --\n")
        val title = o.optString("title")
        val titleLen = o.optInt("titleLen")
        sb.append("Title: $title\n")
        sb.append("Length: $titleLen chars ")
        sb.append(if (titleLen in 30..65) "[OK]" else "[WARN: aim 30-65]")
        sb.append("\n\n")
        sb.append("-- META DESCRIPTION --\n")
        val desc = o.optString("desc")
        val descLen = o.optInt("descLen")
        sb.append("Desc: $desc\n")
        sb.append("Length: $descLen chars ")
        sb.append(if (descLen in 70..165) "[OK]" else "[WARN: aim 70-165]")
        sb.append("\n\n")
        sb.append("-- CANONICAL --\n")
        val can = o.optString("canonical")
        sb.append(if (can.isNotEmpty()) can else "(missing)")
        sb.append("\n\n")
        sb.append("-- ROBOTS META --\n")
        val robots = o.optString("robots")
        sb.append(if (robots.isNotEmpty()) robots else "(none)")
        sb.append("\n\n")
        sb.append("-- HREFLANG --\n")
        val hre = o.optJSONArray("hreflangs")
        if (hre == null || hre.length() == 0) sb.append("(none)\n")
        else for (i in 0 until hre.length()) sb.append("  ${hre.getString(i)}\n")
        sb.append("\n")
        sb.append("-- HEADINGS --\n")
        val h = o.optJSONObject("heads")
        if (h != null) {
            for (i in 1..6) sb.append("  H$i: ${h.optInt("h$i")}\n")
        }
        sb.append("\n")
        sb.append("-- IMAGES --\n")
        sb.append("Total: ${o.optInt("imgsTotal")}, missing alt: ${o.optInt("imgsNoAlt")}\n\n")
        sb.append("-- WORD COUNT --\n")
        sb.append("Words: ${o.optInt("wordCount")}\n\n")
        sb.append("-- TOP KEYWORDS (density) --\n")
        val top = o.optJSONArray("topWords")
        val wc = o.optInt("wordCount").coerceAtLeast(1)
        if (top != null) for (i in 0 until top.length()) {
            val s = top.getString(i)
            val parts = s.split(":")
            if (parts.size == 2) {
                val n = parts[1].toIntOrNull() ?: 0
                val dens = (n * 100.0 / wc)
                sb.append(String.format("  %-18s %4d  %.2f%%\n", parts[0], n, dens))
            } else sb.append("  $s\n")
        }
        sb.append("\n")
        sb.append("-- LINKS --\n")
        sb.append("Internal: ${o.optInt("internalLinks")}\n")
        sb.append("External: ${o.optInt("externalLinks")}\n")
        sb.append("Nofollow: ${o.optInt("nofollowLinks")}\n\n")
        sb.append("-- OPEN GRAPH --\n")
        val og = o.optJSONArray("og")
        if (og == null || og.length() == 0) sb.append("(none)\n")
        else for (i in 0 until og.length()) sb.append("  ${og.getString(i)}\n")
        sb.append("\n")
        sb.append("-- TWITTER CARDS --\n")
        val tw = o.optJSONArray("tw")
        if (tw == null || tw.length() == 0) sb.append("(none)\n")
        else for (i in 0 until tw.length()) sb.append("  ${tw.getString(i)}\n")
        sb.append("\n")
        sb.append("-- JSON-LD SCHEMA BLOCKS --\n")
        val jl = o.optJSONArray("jsonld")
        if (jl == null || jl.length() == 0) sb.append("(none)\n")
        else for (i in 0 until jl.length()) {
            sb.append("  [block ${i + 1}]\n")
            sb.append(jl.getString(i).take(800)).append("\n---\n")
        }
        return sb.toString()
    }

    fun reportToCsv(o: JSONObject): String {
        val sb = StringBuilder()
        sb.append("field,value\n")
        fun row(k: String, v: String) {
            sb.append(k).append(',').append(v.replace(",", ";").replace("\n", " ")).append('\n')
        }
        row("url", o.optString("url"))
        row("title", o.optString("title"))
        row("title_len", o.optInt("titleLen").toString())
        row("meta_description", o.optString("desc"))
        row("meta_description_len", o.optInt("descLen").toString())
        row("canonical", o.optString("canonical"))
        row("robots", o.optString("robots"))
        row("word_count", o.optInt("wordCount").toString())
        row("images_total", o.optInt("imgsTotal").toString())
        row("images_no_alt", o.optInt("imgsNoAlt").toString())
        row("internal_links", o.optInt("internalLinks").toString())
        row("external_links", o.optInt("externalLinks").toString())
        row("nofollow_links", o.optInt("nofollowLinks").toString())
        val h = o.optJSONObject("heads")
        if (h != null) for (i in 1..6) row("h$i_count", h.optInt("h$i").toString())
        return sb.toString()
    }

    fun unquote(v: String?): String {
        if (v == null) return ""
        var s = v
        if (s.length >= 2 && s.startsWith("\"") && s.endsWith("\"")) {
            s = s.substring(1, s.length - 1)
        }
        s = s.replace("\\u003d", "=")
            .replace("\\u003c", "<")
            .replace("\\u003e", ">")
            .replace("\\\"", "\"")
            .replace("\\n", "\n")
            .replace("\\/", "/")
        return s
    }
}
