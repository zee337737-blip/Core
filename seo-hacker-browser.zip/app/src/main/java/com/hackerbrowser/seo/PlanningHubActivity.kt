package com.hackerbrowser.seo

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.text.InputType
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONArray
import org.json.JSONObject
import kotlin.concurrent.thread

class PlanningHubActivity : AppCompatActivity() {

    private lateinit var etKey: EditText
    private lateinit var etModel: EditText
    private lateinit var reportsContainer: LinearLayout
    private lateinit var tvResult: TextView

    private val FILE_CSV_REQ = 9001
    private var csvCallback: ((String) -> Unit)? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_planning_hub)

        etKey = findViewById(R.id.etKey)
        etModel = findViewById(R.id.etModel)
        reportsContainer = findViewById(R.id.reportsContainer)
        tvResult = findViewById(R.id.tvResult)

        etKey.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        etKey.setText(Prefs.getCohereKey(this))
        etModel.setText(Prefs.getCohereModel(this))

        findViewById<Button>(R.id.btnSave).setOnClickListener {
            Prefs.setCohereKey(this, etKey.text.toString().trim())
            Prefs.setCohereModel(this, etModel.text.toString().trim().ifEmpty { "command-r-plus-08-2024" })
            Toast.makeText(this, "Saved locally", Toast.LENGTH_SHORT).show()
        }

        findViewById<Button>(R.id.btnClear).setOnClickListener {
            Prefs.setReports(this, "[]")
            refreshReports()
        }

        findViewById<Button>(R.id.btnImport).setOnClickListener {
            val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "*/*"
            }
            csvCallback = { text ->
                if (text.isBlank()) {
                    Toast.makeText(this, "CSV read failed", Toast.LENGTH_SHORT).show()
                } else {
                    val title = "CSV import (${text.length} chars)"
                    ReportUtil.addReportToHub(this, title, text.take(50000))
                    refreshReports()
                    Toast.makeText(this, "CSV imported to hub", Toast.LENGTH_SHORT).show()
                }
            }
            @Suppress("DEPRECATION")
            startActivityForResult(intent, FILE_CSV_REQ)
        }

        findViewById<Button>(R.id.btnGenerate).setOnClickListener {
            generateStrategy()
        }

        refreshReports()
    }

    override fun onResume() {
        super.onResume()
        refreshReports()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == FILE_CSV_REQ) {
            val cb = csvCallback
            csvCallback = null
            if (resultCode != Activity.RESULT_OK || data?.data == null) { cb?.invoke(""); return }
            try {
                val text = contentResolver.openInputStream(data.data!!)
                    ?.bufferedReader()?.use { it.readText() } ?: ""
                cb?.invoke(text)
            } catch (e: Exception) {
                cb?.invoke("")
            }
        }
    }

    private fun refreshReports() {
        reportsContainer.removeAllViews()
        val arr = try { JSONArray(Prefs.getReports(this)) } catch (_: Exception) { JSONArray() }
        if (arr.length() == 0) {
            val tv = TextView(this)
            tv.text = "(no reports in queue - send them from the browser via 'Send to Hub?')"
            tv.setTextColor(0xFF007A4B.toInt())
            tv.textSize = 11f
            reportsContainer.addView(tv)
            return
        }
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val row = LinearLayout(this)
            row.orientation = LinearLayout.VERTICAL
            row.setPadding(0, 8, 0, 8)

            val title = TextView(this)
            title.text = "[${i + 1}] ${o.optString("title")}"
            title.setTextColor(0xFF00FF9C.toInt())
            title.textSize = 12f
            row.addView(title)

            val btns = LinearLayout(this)
            btns.orientation = LinearLayout.HORIZONTAL

            val show = Button(this)
            show.text = "VIEW"
            show.setTextColor(0xFF00FF9C.toInt())
            show.textSize = 10f
            show.background = null
            show.setOnClickListener {
                ReportUtil.showReport(
                    this, o.optString("title"), o.optString("content")
                )
            }
            btns.addView(show)

            val del = Button(this)
            del.text = "REMOVE"
            del.setTextColor(0xFFFF3B3B.toInt())
            del.textSize = 10f
            del.background = null
            del.setOnClickListener {
                removeReport(i)
                refreshReports()
            }
            btns.addView(del)

            row.addView(btns)
            reportsContainer.addView(row)

            val divider = android.view.View(this)
            divider.layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 1
            )
            divider.setBackgroundColor(0xFF007A4B.toInt())
            reportsContainer.addView(divider)
        }
    }

    private fun removeReport(index: Int) {
        try {
            val arr = JSONArray(Prefs.getReports(this))
            val out = JSONArray()
            for (i in 0 until arr.length()) if (i != index) out.put(arr.get(i))
            Prefs.setReports(this, out.toString())
        } catch (_: Exception) {}
    }

    private fun generateStrategy() {
        val key = Prefs.getCohereKey(this).trim()
        val model = Prefs.getCohereModel(this).trim().ifEmpty { "command-r-plus-08-2024" }
        if (key.isBlank()) {
            tvResult.text = "[!] No Cohere API key. Enter your key above and tap SAVE."
            return
        }
        val arr = try { JSONArray(Prefs.getReports(this)) } catch (_: Exception) { JSONArray() }
        if (arr.length() == 0) {
            tvResult.text = "[!] No reports in the queue."
            return
        }

        val sb = StringBuilder()
        sb.append("You are an expert SEO strategist. Analyze the following ")
        sb.append("SEO reports (may include page analysis and imported CSVs from ")
        sb.append("Google Trends / Ads Keyword Planner). Provide:\n")
        sb.append("1) PROBLEMS FOUND (bulleted)\n")
        sb.append("2) ACTION PLAN (prioritized, bulleted)\n")
        sb.append("3) BETTER SEO STRATEGY (including keyword planning)\n\n")
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            sb.append("=== REPORT ${i + 1}: ${o.optString("title")} ===\n")
            sb.append(o.optString("content").take(8000)).append("\n\n")
        }

        tvResult.text = "[*] Asking AI..."

        thread {
            try {
                val client = CohereClient(key, model)
                val resp = client.chat(sb.toString())
                runOnUiThread {
                    tvResult.text = resp
                    ReportUtil.addReportToHub(
                        this,
                        "AI strategy ${System.currentTimeMillis()}",
                        resp
                    )
                }
            } catch (e: Exception) {
                runOnUiThread {
                    val msg = e.message ?: ""
                    val friendly = when {
                        msg.contains("No Cohere API key") -> "[!] No Cohere API key configured."
                        msg.contains("HTTP 401") -> "[!] Cohere rejected the key (401). Check your API key."
                        msg.contains("HTTP 429") -> "[!] Rate limit or quota reached (429)."
                        msg.contains("UnknownHost") || msg.contains("Network") -> "[!] No internet connection."
                        else -> "[!] Error: $msg"
                    }
                    tvResult.text = friendly
                }
            }
        }
    }
}
