package com.hackerbrowser.seo

import android.content.Intent
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.ListView
import androidx.appcompat.app.AppCompatActivity
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class HistoryActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_history)

        val listView = findViewById<ListView>(R.id.historyList)
        val fmt = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US)

        fun refresh() {
            val items = HistoryStore.list(this)
            val labels = items.map { "${fmt.format(Date(it.time))}\n${it.title}\n${it.url}" }
            listView.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, labels)
        }
        refresh()

        listView.setOnItemClickListener { _, _, position, _ ->
            val items = HistoryStore.list(this)
            if (position in items.indices) {
                val i = Intent(this, MainActivity::class.java)
                i.putExtra("history_url", items[position].url)
                startActivity(i)
                finish()
            }
        }

        findViewById<Button>(R.id.btnClearHistory).setOnClickListener {
            HistoryStore.clear(this)
            refresh()
        }
    }
}
