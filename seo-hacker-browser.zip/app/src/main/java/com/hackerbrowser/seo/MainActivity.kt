package com.hackerbrowser.seo

import android.annotation.SuppressLint
import android.app.Activity
import android.app.DownloadManager
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.util.Log
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.webkit.CookieManager
import android.webkit.DownloadListener
import android.webkit.JavascriptInterface
import android.webkit.URLUtil
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.ArrayAdapter
import android.widget.PopupMenu
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.drawerlayout.widget.DrawerLayout
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Locale
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity() {

    private lateinit var drawer: DrawerLayout
    private lateinit var omnibox: EditText
    private lateinit var progress: ProgressBar
    private lateinit var webContainer: FrameLayout
    private lateinit var suggestions: ListView
    private lateinit var fullscreenContainer: FrameLayout
    private lateinit var bookmarksList: ListView

    private val tabs = mutableListOf<WebView>()
    private var currentTab = -1
    private var desktopMode = false
    private var filePathCallback: ValueCallback<Array<Uri>>? = null
    private val FILE_CHOOSER_REQ = 1001
    private val FILE_IMPORT_REQ = 1002
    private var importCallback: ((String) -> Unit)? = null

    private var customView: View? = null
    private var customViewCallback: WebChromeClient.CustomViewCallback? = null

    private val suggestionsAdapter = arrayListOf<String>()
    private lateinit var suggestionsArrayAdapter: ArrayAdapter<String>

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        drawer = findViewById(R.id.drawer)
        omnibox = findViewById(R.id.omnibox)
        progress = findViewById(R.id.progress)
        webContainer = findViewById(R.id.webContainer)
        suggestions = findViewById(R.id.suggestions)
        fullscreenContainer = findViewById(R.id.fullscreenContainer)
        bookmarksList = findViewById(R.id.bookmarksList)

        desktopMode = Prefs.getDesktopMode(this)

        AdBlocker.load(this)

        val tools = listOf(
            "\u25b6 ANALYZE PAGE",
            "\u25b6 VIEW SOURCE",
            "\u25b6 REDIRECT CHAIN",
            "\u25b6 RESPONSE HEADERS",
            "\u25b6 ROBOTS.TXT",
            "\u25b6 SITEMAP.XML",
            "\u25b6 BROKEN LINK CHECKER",
            "\u25b6 PAGE SPEED & SIZE",
            "\u25b6 USER-AGENT SWITCHER",
            "\u25b6 SEARCH ENGINE",
            "\u25b6 TOGGLE AD-BLOCK",
            "\u25b6 RESET AD-BLOCK COUNTER",
            "\u25b6 HISTORY",
            "\u25b6 PLANNING HUB",
            "\u25b6 NEW TAB",
            "\u25b6 CLOSE TAB",
            "\u25b6 TABS",
            "\u25b6 FIND IN PAGE",
            "\u25b6 DESKTOP MODE"
        )
        val toolsContainer = findViewById<LinearLayout>(R.id.toolsContainer)
        tools.forEach { label ->
            val b = Button(this)
            b.text = label
            b.setTextColor(0xFF00FF9C.toInt())
            b.background = null
            b.textSize = 12f
            b.gravity = Gravity.START or Gravity.CENTER_VERTICAL
            b.isAllCaps = false
            b.setOnClickListener { onToolClicked(label) }
            toolsContainer.addView(b)
        }

        suggestionsArrayAdapter = ArrayAdapter(
            this, android.R.layout.simple_list_item_1, suggestionsAdapter
        )
        suggestions.adapter = suggestionsArrayAdapter
        suggestions.setOnItemClickListener { _, _, position, _ ->
            val s = suggestionsAdapter[position]
            suggestions.visibility = View.GONE
            loadQuery(s)
            hideKeyboard()
        }

        findViewById<Button>(R.id.btnMenu).setOnClickListener {
            drawer.openDrawer(Gravity.START)
        }
        findViewById<Button>(R.id.btnBack).setOnClickListener { currentWeb()?.goBack() }
        findViewById<Button>(R.id.btnForward).setOnClickListener { currentWeb()?.goForward() }
        findViewById<Button>(R.id.btnReload).setOnClickListener {
            val w = currentWeb() ?: return@setOnClickListener
            if (w.progress < 100) w.stopLoading() else w.reload()
        }
        findViewById<Button>(R.id.btnBookmark).setOnClickListener {
            val w = currentWeb() ?: return@setOnClickListener
            val url = w.url ?: return@setOnClickListener
            AlertDialog.Builder(this)
                .setTitle("Bookmark")
                .setMessage("Add current page to bookmarks?")
                .setPositiveButton("Yes") { _, _ ->
                    BookmarkStore.add(this, w.title ?: url, url)
                    refreshBookmarks()
                    Toast.makeText(this, "Bookmarked", Toast.LENGTH_SHORT).show()
                }
                .setNegativeButton("No", null)
                .show()
        }
        findViewById<Button>(R.id.btnMore).setOnClickListener { showOverflow(it) }

        omnibox.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_GO || actionId == EditorInfo.IME_ACTION_DONE) {
                suggestions.visibility = View.GONE
                loadQuery(omnibox.text.toString())
                hideKeyboard()
                true
            } else false
        }
        omnibox.setOnKeyListener { _, keyCode, event ->
            if (keyCode == KeyEvent.KEYCODE_ENTER && event.action == KeyEvent.ACTION_DOWN) {
                suggestions.visibility = View.GONE
                loadQuery(omnibox.text.toString())
                hideKeyboard()
                true
            } else false
        }
        omnibox.addTextChangedListener(object : android.text.TextWatcher {
            override fun afterTextChanged(s: android.text.Editable?) {}
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {
                val q = s?.toString()?.trim() ?: ""
                if (q.length >= 2) fetchSuggestions(q) else {
                    suggestions.visibility = View.GONE
                }
            }
        })
        omnibox.setOnFocusChangeListener { _, hasFocus ->
            if (!hasFocus) suggestions.visibility = View.GONE
        }

        bookmarksList.setOnItemClickListener { _, _, position, _ ->
            val list = BookmarkStore.list(this)
            if (position in list.indices) {
                val b = list[position]
                openInCurrentTab(b.url)
                drawer.closeDrawer(Gravity.END)
            }
        }
        bookmarksList.setOnItemLongClickListener { _, _, position, _ ->
            val list = BookmarkStore.list(this)
            if (position in list.indices) {
                val b = list[position]
                AlertDialog.Builder(this)
                    .setTitle("Delete bookmark?")
                    .setMessage(b.url)
                    .setPositiveButton("Delete") { _, _ ->
                        BookmarkStore.remove(this, b.url)
                        refreshBookmarks()
                    }
                    .setNegativeButton("Cancel", null)
                    .show()
                true
            } else false
        }

        fullscreenContainer.setOnClickListener { hideFullscreen() }

        newTab("file:///android_asset/index.html")

        val histUrl = intent?.getStringExtra("history_url")
        if (!histUrl.isNullOrEmpty()) {
            currentWeb()?.loadUrl(histUrl)
        }
    }

    private fun onToolClicked(label: String) {
        drawer.closeDrawer(Gravity.START)
        when (label) {
            "\u25b6 ANALYZE PAGE" -> toolAnalyzePage()
            "\u25b6 VIEW SOURCE" -> toolViewSource()
            "\u25b6 REDIRECT CHAIN" -> toolRedirectChain()
            "\u25b6 RESPONSE HEADERS" -> toolHeaders()
            "\u25b6 ROBOTS.TXT" -> toolRobots()
            "\u25b6 SITEMAP.XML" -> toolSitemap()
            "\u25b6 BROKEN LINK CHECKER" -> toolBrokenLinks()
            "\u25b6 PAGE SPEED & SIZE" -> toolPageSpeed()
            "\u25b6 USER-AGENT SWITCHER" -> toolUserAgent()
            "\u25b6 SEARCH ENGINE" -> toolSearchEngine()
            "\u25b6 TOGGLE AD-BLOCK" -> {
                val on = !Prefs.getAdBlock(this)
                Prefs.setAdBlock(this, on)
                Toast.makeText(this, if (on) "Ad-block ON" else "Ad-block OFF", Toast.LENGTH_SHORT).show()
                currentWeb()?.reload()
            }
            "\u25b6 RESET AD-BLOCK COUNTER" -> {
                AdBlocker.resetCount()
                Toast.makeText(this, "Ad-block counter reset", Toast.LENGTH_SHORT).show()
            }
            "\u25b6 HISTORY" -> startActivity(Intent(this, HistoryActivity::class.java))
            "\u25b6 PLANNING HUB" -> startActivity(Intent(this, PlanningHubActivity::class.java))
            "\u25b6 NEW TAB" -> newTab("file:///android_asset/index.html")
            "\u25b6 CLOSE TAB" -> closeTab(currentTab)
            "\u25b6 TABS" -> showTabsDialog()
            "\u25b6 FIND IN PAGE" -> showFindDialog()
            "\u25b6 DESKTOP MODE" -> {
                desktopMode = !desktopMode
                Prefs.setDesktopMode(this, desktopMode)
                applyDesktopMode()
                Toast.makeText(this, if (desktopMode) "Desktop" else "Mobile", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun showOverflow(anchor: View) {
        val popup = PopupMenu(this, anchor)
        popup.menu.add("New tab")
        popup.menu.add("Close current tab")
        popup.menu.add("Tabs")
        popup.menu.add("Find in page")
        popup.menu.add("History")
        popup.menu.add("Bookmarks")
        popup.menu.add("Planning Hub")
        popup.menu.add(if (desktopMode) "Mobile mode" else "Desktop mode")
        popup.setOnMenuItemClickListener { item ->
            when (item.title.toString()) {
                "New tab" -> newTab("file:///android_asset/index.html")
                "Close current tab" -> closeTab(currentTab)
                "Tabs" -> showTabsDialog()
                "Find in page" -> showFindDialog()
                "History" -> startActivity(Intent(this, HistoryActivity::class.java))
                "Bookmarks" -> drawer.openDrawer(Gravity.END)
                "Planning Hub" -> startActivity(Intent(this, PlanningHubActivity::class.java))
                "Desktop mode", "Mobile mode" -> {
                    desktopMode = !desktopMode
                    Prefs.setDesktopMode(this, desktopMode)
                    applyDesktopMode()
                }
            }
            true
        }
        popup.show()
    }

    private fun applyDesktopMode() {
        tabs.forEach { w ->
            val s = w.settings
            s.userAgentString = if (desktopMode) DESKTOP_UA else MOBILE_UA
            s.loadWithOverviewMode = true
            s.useWideViewPort = true
            w.reload()
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun createWebView(): WebView {
        val w = WebView(this)
        w.layoutParams = FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
        )
        val s = w.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.databaseEnabled = true
        s.loadWithOverviewMode = true
        s.useWideViewPort = true
        s.builtInZoomControls = true
        s.displayZoomControls = false
        s.setSupportZoom(true)
        s.allowFileAccess = true
        s.allowContentAccess = true
        s.javaScriptCanOpenWindowsAutomatically = true
        s.mediaPlaybackRequiresUserGesture = false
        s.userAgentString = if (desktopMode) DESKTOP_UA else MOBILE_UA
        if (Build.VERSION.SDK_INT >= 21) s.mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(w, true)

        w.addJavascriptInterface(object {
            @JavascriptInterface
            fun search(q: String) {
                runOnUiThread { loadQuery(q) }
            }
        }, "Android")

        w.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                return false
            }

            override fun shouldInterceptRequest(
                view: WebView?, request: WebResourceRequest?
            ): WebResourceResponse? {
                if (request != null && Prefs.getAdBlock(this@MainActivity)) {
                    val host = try { request.url.host } catch (_: Exception) { null }
                    if (AdBlocker.isBlocked(host)) {
                        AdBlocker.blockedCount.incrementAndGet()
                        return WebResourceResponse("text/plain", "utf-8",
                            java.io.ByteArrayInputStream(ByteArray(0)))
                    }
                }
                return null
            }

            override fun onPageStarted(view: WebView?, url: String?, favicon: android.graphics.Bitmap?) {
                super.onPageStarted(view, url, favicon)
                progress.visibility = View.VISIBLE
                progress.progress = 5
                omnibox.setText(url ?: "")
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                progress.visibility = View.GONE
                if (url != null) {
                    omnibox.setText(url)
                    HistoryStore.add(
                        this@MainActivity,
                        view?.title ?: url,
                        url
                    )
                }
                if (Prefs.getAdBlock(this@MainActivity)) {
                    view?.evaluateJavascript(AdBlocker.HIDE_ADS_CSS, null)
                }
                updateOmniboxFromCurrent()
            }
        }

        w.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                progress.progress = newProgress
                if (newProgress >= 100) progress.visibility = View.GONE
            }

            override fun onReceivedTitle(view: WebView?, title: String?) {
                super.onReceivedTitle(view, title)
                if (view == currentWeb()) {
                    title?.let { omnibox.hint = it }
                }
            }

            override fun onShowFileChooser(
                webView: WebView?,
                callback: ValueCallback<Array<Uri>>?,
                params: FileChooserParams?
            ): Boolean {
                filePathCallback?.onReceiveValue(null)
                filePathCallback = callback
                try {
                    val intent = params?.createIntent() ?: Intent(Intent.ACTION_GET_CONTENT).apply {
                        type = "*/*"
                        addCategory(Intent.CATEGORY_OPENABLE)
                    }
                    intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
                    startActivityForResult(Intent.createChooser(intent, "Choose files"), FILE_CHOOSER_REQ)
                } catch (e: ActivityNotFoundException) {
                    filePathCallback = null
                    return false
                }
                return true
            }

            override fun onShowCustomView(view: View?, callback: CustomViewCallback?) {
                if (customView != null) {
                    callback?.onCustomViewHidden()
                    return
                }
                customView = view
                customViewCallback = callback
                fullscreenContainer.addView(view)
                fullscreenContainer.visibility = View.VISIBLE
                window.decorView.systemUiVisibility = (
                    View.SYSTEM_UI_FLAG_FULLSCREEN
                        or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                    )
            }

            override fun onHideCustomView() {
                hideFullscreen()
            }
        }

        w.setDownloadListener(DownloadListener { url, userAgent, contentDisposition, mimetype, _ ->
            try {
                val filename = URLUtil.guessFileName(url, contentDisposition, mimetype)
                val request = DownloadManager.Request(Uri.parse(url))
                request.setMimeType(mimetype)
                request.addRequestHeader("User-Agent", userAgent)
                request.addRequestHeader("cookie", CookieManager.getInstance().getCookie(url))
                request.setDescription("Downloading...")
                request.setTitle(filename)
                request.allowScanningByMediaScanner()
                request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, filename)
                val dm = getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
                dm.enqueue(request)
                Toast.makeText(this, "Download started: $filename", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Toast.makeText(this, "Download failed: ${e.message}", Toast.LENGTH_LONG).show()
            }
        })

        w.setOnLongClickListener {
            val hr = w.hitTestResult
            val extra = hr.extra
            if (extra != null && (hr.type == android.webkit.WebView.HitTestResult.SRC_ANCHOR_TYPE ||
                        hr.type == android.webkit.WebView.HitTestResult.SRC_IMAGE_ANCHOR_TYPE)) {
                AlertDialog.Builder(this)
                    .setTitle("Link")
                    .setItems(arrayOf("Open in new tab", "Copy URL")) { _, which ->
                        when (which) {
                            0 -> newTab(extra)
                            1 -> {
                                val cm = getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                                cm.setPrimaryClip(android.content.ClipData.newPlainText("url", extra))
                                Toast.makeText(this, "Copied", Toast.LENGTH_SHORT).show()
                            }
                        }
                    }
                    .show()
                true
            } else false
        }

        return w
    }

    private fun newTab(url: String) {
        val w = createWebView()
        tabs.add(w)
        webContainer.addView(w)
        selectTab(tabs.size - 1)
        w.loadUrl(url)
    }

    private fun selectTab(index: Int) {
        if (index !in tabs.indices) return
        currentTab = index
        for (i in tabs.indices) {
            tabs[i].visibility = if (i == index) View.VISIBLE else View.GONE
        }
        updateOmniboxFromCurrent()
        invalidateOptionsMenuSafe()
    }

    private fun closeTab(index: Int) {
        if (index !in tabs.indices) return
        val w = tabs.removeAt(index)
        webContainer.removeView(w)
        w.destroy()
        if (tabs.isEmpty()) {
            newTab("file:///android_asset/index.html")
            return
        }
        selectTab(index.coerceAtMost(tabs.size - 1))
    }

    private fun currentWeb(): WebView? = if (currentTab in tabs.indices) tabs[currentTab] else null

    private fun updateOmniboxFromCurrent() {
        val w = currentWeb() ?: return
        val u = w.url
        if (u != null) omnibox.setText(u)
    }

    private fun invalidateOptionsMenuSafe() {}

    private fun openInCurrentTab(url: String) {
        currentWeb()?.loadUrl(url) ?: newTab(url)
    }

    private fun showTabsDialog() {
        val labels = tabs.mapIndexed { i, w ->
            val t = w.title ?: w.url ?: "tab"
            "$i. $t"
        }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Tabs (${tabs.size})")
            .setItems(labels) { _, which -> selectTab(which) }
            .setNegativeButton("Close current") { _, _ -> closeTab(currentTab) }
            .setPositiveButton("New tab") { _, _ -> newTab("file:///android_asset/index.html") }
            .show()
    }

    private fun showFindDialog() {
        val input = EditText(this)
        input.hint = "Find in page"
        AlertDialog.Builder(this)
            .setTitle("Find in page")
            .setView(input)
            .setPositiveButton("Find") { _, _ ->
                currentWeb()?.findAllAsync(input.text.toString())
            }
            .setNeutralButton("Clear") { _, _ ->
                currentWeb()?.clearMatches()
            }
            .setNegativeButton("Close", null)
            .show()
    }

    private fun refreshBookmarks() {
        val list = BookmarkStore.list(this)
        val titles = list.map { "${it.title}\n${it.url}" }
        bookmarksList.adapter = ArrayAdapter(
            this, android.R.layout.simple_list_item_1, titles
        )
    }

    override fun onResume() {
        super.onResume()
        refreshBookmarks()
    }

    private fun hideKeyboard() {
        try {
            val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.hideSoftInputFromWindow(omnibox.windowToken, 0)
            omnibox.clearFocus()
        } catch (_: Exception) {}
    }

    private fun isUrl(text: String): Boolean {
        val t = text.trim()
        if (t.isEmpty()) return false
        if (t.startsWith("http://") || t.startsWith("https://")) return true
        if (t.contains(" ")) return false
        return t.contains(".")
    }

    private fun searchEngineUrl(q: String): String {
        val enc = URLEncoder.encode(q, "UTF-8")
        return when (Prefs.getSearchEngine(this)) {
            "bing" -> "https://www.bing.com/search?q=$enc"
            "duckduckgo" -> "https://duckduckgo.com/?q=$enc"
            else -> "https://www.google.com/search?q=$enc"
        }
    }

    private fun loadQuery(text: String) {
        val t = text.trim()
        if (t.isEmpty()) return
        val url = if (isUrl(t)) {
            if (t.startsWith("http://") || t.startsWith("https://")) t else "https://$t"
        } else searchEngineUrl(t)
        currentWeb()?.loadUrl(url) ?: newTab(url)
    }

    private var suggestThread: Thread? = null

    private fun fetchSuggestions(q: String) {
        suggestThread?.interrupt()
        suggestThread = thread {
            try {
                val enc = URLEncoder.encode(q, "UTF-8")
                val url = URL("https://suggestqueries.google.com/complete/search?client=firefox&q=$enc")
                val conn = url.openConnection() as HttpURLConnection
                conn.connectTimeout = 5000
                conn.readTimeout = 5000
                val txt = conn.inputStream.bufferedReader().use(BufferedReader::readText)
                val arr = JSONArray(txt)
                val list = arr.optJSONArray(1) ?: JSONArray()
                val out = ArrayList<String>()
                for (i in 0 until list.length()) out.add(list.getString(i))
                runOnUiThread {
                    suggestionsAdapter.clear()
                    suggestionsAdapter.addAll(out)
                    suggestionsArrayAdapter.notifyDataSetChanged()
                    suggestions.visibility = if (out.isEmpty()) View.GONE else View.VISIBLE
                }
            } catch (_: Exception) {}
        }
    }

    private fun toolAnalyzePage() {
        val w = currentWeb() ?: return
        SeoAnalyzer.runMainAnalysis(w) { obj ->
            if (obj == null) {
                Toast.makeText(this, "Analysis failed", Toast.LENGTH_SHORT).show()
                return@runMainAnalysis
            }
            val txt = SeoAnalyzer.formatReport(obj)
            ReportUtil.showReport(this, "SEO Report", txt)
        }
    }

    private fun toolViewSource() {
        val w = currentWeb() ?: return
        w.evaluateJavascript("(function(){try{return document.documentElement.outerHTML;}catch(e){return '';}})();") { v ->
            val html = SeoAnalyzer.unquote(v)
            ReportUtil.showReport(this, "Page Source", html.take(200000))
        }
    }

    private fun toolRedirectChain() {
        val url = currentWeb()?.url ?: return
        runNetwork("Redirect chain for $url") { out ->
            var current = url
            var hops = 0
            out.append("start: $current\n")
            while (hops < 10) {
                val c = URL(current).openConnection() as HttpURLConnection
                c.instanceFollowRedirects = false
                c.connectTimeout = 10000
                c.readTimeout = 10000
                c.requestMethod = "GET"
                c.setRequestProperty("User-Agent", MOBILE_UA)
                val code = c.responseCode
                val loc = c.getHeaderField("Location")
                out.append("[$hops] $code  $current\n")
                if (loc != null && code in 300..399) {
                    current = if (loc.startsWith("http")) loc else URL(URL(current), loc).toString()
                    hops++
                } else break
                c.disconnect()
            }
            if (hops >= 10) out.append("(stopped: too many redirects)\n")
        }
    }

    private fun toolHeaders() {
        val url = currentWeb()?.url ?: return
        runNetwork("Response headers for $url") { out ->
            val c = URL(url).openConnection() as HttpURLConnection
            c.connectTimeout = 10000
            c.readTimeout = 10000
            c.requestMethod = "GET"
            c.setRequestProperty("User-Agent", MOBILE_UA)
            c.instanceFollowRedirects = false
            out.append("HTTP ${c.responseCode} ${c.responseMessage}\n\n")
            for ((k, v) in c.headerFields) {
                if (k == null) continue
                out.append("$k: ${v.joinToString(", ")}\n")
            }
            c.disconnect()
        }
    }

    private fun toolRobots() {
        val base = originOf(currentWeb()?.url) ?: return
        runNetwork("robots.txt for $base") { out ->
            val c = URL("$base/robots.txt").openConnection() as HttpURLConnection
            c.setRequestProperty("User-Agent", MOBILE_UA)
            c.connectTimeout = 10000; c.readTimeout = 10000
            val code = c.responseCode
            out.append("HTTP $code\n\n")
            c.inputStream.bufferedReader().use { out.append(it.readText()) }
            c.disconnect()
        }
    }

    private fun toolSitemap() {
        val base = originOf(currentWeb()?.url) ?: return
        runNetwork("sitemap.xml for $base") { out ->
            val url = "$base/sitemap.xml"
            val c = URL(url).openConnection() as HttpURLConnection
            c.setRequestProperty("User-Agent", MOBILE_UA)
            c.connectTimeout = 10000; c.readTimeout = 10000
            val code = c.responseCode
            out.append("HTTP $code\n\n")
            if (code in 200..299) {
                c.inputStream.bufferedReader().use { out.append(it.readText().take(200000)) }
            }
            c.disconnect()
        }
    }

    private fun toolBrokenLinks() {
        val w = currentWeb() ?: return
        SeoAnalyzer.runMainAnalysis(w) { obj ->
            val links = obj?.optJSONArray("links") ?: return@runMainAnalysis
            val urls = ArrayList<String>()
            for (i in 0 until links.length()) {
                val u = links.getString(i)
                if (u.startsWith("http")) urls.add(u)
                if (urls.size >= 40) break
            }
            runNetwork("Broken link check (${urls.size} links)") { out ->
                urls.forEach { u ->
                    var status = "ERR"
                    try {
                        val c = URL(u).openConnection() as HttpURLConnection
                        c.instanceFollowRedirects = false
                        c.requestMethod = "HEAD"
                        c.connectTimeout = 8000
                        c.readTimeout = 8000
                        c.setRequestProperty("User-Agent", MOBILE_UA)
                        status = c.responseCode.toString()
                        c.disconnect()
                    } catch (_: Exception) {}
                    out.append("$status  $u\n")
                }
            }
        }
    }

    private fun toolPageSpeed() {
        val url = currentWeb()?.url ?: return
        runNetwork("Page speed & size for $url") { out ->
            val t0 = System.currentTimeMillis()
            val c = URL(url).openConnection() as HttpURLConnection
            c.setRequestProperty("User-Agent", MOBILE_UA)
            c.connectTimeout = 20000; c.readTimeout = 20000
            val stream = c.inputStream
            var total = 0L
            val buf = ByteArray(8192)
            while (true) {
                val n = stream.read(buf)
                if (n <= 0) break
                total += n
            }
            val t1 = System.currentTimeMillis()
            out.append("URL: $url\n")
            out.append("HTTP: ${c.responseCode}\n")
            out.append("Elapsed: ${t1 - t0} ms\n")
            out.append("Size: $total bytes (%.2f KB)\n".format(Locale.US, total / 1024.0))
            c.disconnect()
        }
    }

    private fun toolUserAgent() {
        val options = arrayOf(
            "Mobile (default)",
            "Desktop Chrome",
            "Googlebot Smartphone",
            "Googlebot Desktop"
        )
        AlertDialog.Builder(this)
            .setTitle("User-Agent")
            .setItems(options) { _, which ->
                val ua = when (which) {
                    0 -> MOBILE_UA
                    1 -> DESKTOP_UA
                    2 -> "Mozilla/5.0 (Linux; Android 6.0.1; Nexus 5X Build/MMB29P) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/W.X.Y.Z Mobile Safari/537.36 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)"
                    else -> "Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)"
                }
                currentWeb()?.settings?.userAgentString = ua
                currentWeb()?.reload()
                Toast.makeText(this, "UA set", Toast.LENGTH_SHORT).show()
            }
            .show()
    }

    private fun toolSearchEngine() {
        val options = arrayOf("Google", "Bing", "DuckDuckGo")
        val current = Prefs.getSearchEngine(this)
        val idx = when (current) { "bing" -> 1; "duckduckgo" -> 2; else -> 0 }
        AlertDialog.Builder(this)
            .setTitle("Search engine")
            .setSingleChoiceItems(options, idx) { d, which ->
                val v = when (which) { 1 -> "bing"; 2 -> "duckduckgo"; else -> "google" }
                Prefs.setSearchEngine(this, v)
                Toast.makeText(this, "Search engine: ${options[which]}", Toast.LENGTH_SHORT).show()
                d.dismiss()
            }
            .show()
    }

    private fun originOf(url: String?): String? {
        if (url == null) return null
        return try {
            val u = URL(url)
            "${u.protocol}://${u.host}"
        } catch (_: Exception) { null }
    }

    private fun runNetwork(title: String, block: (StringBuilder) -> Unit) {
        thread {
            val out = StringBuilder()
            try {
                block(out)
            } catch (e: Exception) {
                out.append("\n[ERROR] ${e.javaClass.simpleName}: ${e.message}")
            }
            runOnUiThread {
                ReportUtil.showReport(this, title, out.toString())
            }
        }
    }

    private fun hideFullscreen() {
        fullscreenContainer.removeAllViews()
        fullscreenContainer.visibility = View.GONE
        customView = null
        customViewCallback?.onCustomViewHidden()
        customViewCallback = null
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_VISIBLE
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (drawer.isDrawerOpen(Gravity.START)) {
            drawer.closeDrawer(Gravity.START); return
        }
        if (drawer.isDrawerOpen(Gravity.END)) {
            drawer.closeDrawer(Gravity.END); return
        }
        if (fullscreenContainer.visibility == View.VISIBLE) {
            hideFullscreen(); return
        }
        if (suggestions.visibility == View.VISIBLE) {
            suggestions.visibility = View.GONE; return
        }
        val w = currentWeb()
        if (w != null && w.canGoBack()) {
            w.goBack()
        } else {
            @Suppress("DEPRECATION")
            super.onBackPressed()
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == FILE_CHOOSER_REQ) {
            val cb = filePathCallback ?: return
            filePathCallback = null
            if (resultCode != Activity.RESULT_OK) {
                cb.onReceiveValue(null); return
            }
            val results = mutableListOf<Uri>()
            val clip = data?.clipData
            if (clip != null) {
                for (i in 0 until clip.itemCount) results.add(clip.getItemAt(i).uri)
            } else {
                data?.data?.let { results.add(it) }
            }
            cb.onReceiveValue(if (results.isEmpty()) null else results.toTypedArray())
            return
        }
        if (requestCode == FILE_IMPORT_REQ) {
            val cb = importCallback ?: return
            importCallback = null
            if (resultCode != Activity.RESULT_OK || data?.data == null) { cb(""); return }
            try {
                val text = contentResolver.openInputStream(data.data!!)
                    ?.bufferedReader()?.use { it.readText() } ?: ""
                cb(text)
            } catch (e: Exception) {
                cb("")
            }
        }
    }

    companion object {
        const val MOBILE_UA =
            "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"
        const val DESKTOP_UA =
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
    }
}
