package com.hackerbrowser.seo

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

object BookmarkStore {
    data class Bookmark(val title: String, val url: String)

    fun list(c: Context): MutableList<Bookmark> {
        val out = mutableListOf<Bookmark>()
        try {
            val arr = JSONArray(Prefs.getBookmarks(c))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(Bookmark(o.optString("title"), o.optString("url")))
            }
        } catch (_: Exception) {}
        return out
    }

    fun add(c: Context, title: String, url: String) {
        val list = list(c)
        if (list.any { it.url == url }) return
        list.add(0, Bookmark(title, url))
        save(c, list)
    }

    fun remove(c: Context, url: String) {
        val list = list(c).filter { it.url != url }
        save(c, list)
    }

    private fun save(c: Context, list: List<Bookmark>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(JSONObject().put("title", it.title).put("url", it.url))
        }
        Prefs.setBookmarks(c, arr.toString())
    }
}
