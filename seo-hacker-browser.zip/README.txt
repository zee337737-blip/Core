SEO HACKER BROWSER
==================
A dark "hacker style" Android web browser built for SEO work.

BUILD
-----
1. Push this repo to GitHub.
2. The included GitHub Actions workflow (.github/workflows/build.yml)
   will build a debug APK on every push.
3. Download the artifact "app-debug" from the Actions run.

MANUAL CONFIGURATION
--------------------
- Cohere API key: Open the Planning Hub screen inside the app and paste
  your own key + model name (default: command-r-plus-08-2024). The key is
  stored only in local SharedPreferences on the device, never uploaded.
- Ad blocklist: app/src/main/assets/blocklist.txt (one domain per line).
- Start page: app/src/main/assets/index.html.
- Search engine: configurable from the in-app overflow menu.

FEATURES
--------
- Real omnibox (URL vs. search query), Google/Bing/DuckDuckGo suggestions.
- Multiple tabs, back/forward, reload, find in page.
- Ad blocker with blocklist + CSS hiding + counter + toggle.
- Bookmarks sidebar (right drawer).
- History screen.
- File upload (multiple), file download, fullscreen video.
- SEO tools (left drawer): meta, headings, canonical, robots, hreflang,
  OG/Twitter, JSON-LD, image alts, word count, keyword density,
  link analysis, broken links, view source, redirect chain, headers,
  robots.txt, sitemap.xml, page speed/size, user-agent switcher.
- Every report: CSV + TXT download, and "Send to Planning Hub?".
- Planning Hub: Cohere AI analysis, action plan, strategy, and CSV
  import for Google Trends / Ads Keyword Planner exports.
- No paid APIs. No hard-coded keys.
